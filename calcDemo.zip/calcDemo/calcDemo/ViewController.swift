//
//  ViewController.swift
//  calcDemo
//
//  Created by Mac on 9/20/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtValueB: UITextField!
    
    @IBOutlet weak var txtValueA: UITextField!
    @IBOutlet weak var lblValue: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func btnSum(_ sender: UIButton)
    {

        let a:Int = Int(txtValueA.text!)!
        let b:Int = Int(txtValueB.text!)!
        let sum: Int = (Int(a) ) + (Int(b) )
        
        lblValue.text = "\(sum)"
    }
    
    @IBAction func btnDivid(_ sender: UIButton)
    {
        let a = Double(txtValueA.text!)
        let b = Double(txtValueB.text!)
        let sum: Double = (a! / b!)
         lblValue.text = "\(sum)"
        
    }
    @IBAction func btnMulti(_ sender: UIButton)
    {
        let a:Int = Int(txtValueA.text!)!
        let b:Int = Int(txtValueB.text!)!
        let sum: Int = (Int(a)) * (Int(b))
         lblValue.text = "\(sum)"
    }
    @IBAction func btnMinus(_ sender: UIButton)
    {
        let a:Int = Int(txtValueA.text!)!
        let b:Int = Int(txtValueB.text!)!
        let sum: Int = (Int(a)) - (Int(b))
         lblValue.text = "\(sum)"
    }
    
    
}

